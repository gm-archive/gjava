/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AnyPurchaseOrderServiceImpl.java,v 1.14 2005/12/01 20:53:15 yutayoshida Exp $ */

package com.sun.j2ee.blueprints.anyposervice;

import java.rmi.*;
import javax.xml.soap.*;
import javax.xml.rpc.server.*;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class AnyPurchaseOrderServiceImpl implements
        AnyPurchaseOrderServiceSEI,ServiceLifecycle {

    private ServletEndpointContext context;
    private POXMLUtil xmlUtil;

    public void init(Object context) {
        this.context = (ServletEndpointContext) context;
        xmlUtil = new POXMLUtil();
    }
    
    public void destroy() {}
    
    public SubmitPOResponse submitPO(SubmitPO request) throws InvalidPOException, RemoteException {

        String id = null;
        SubmitPOResponse reply = null;

        try{
            SOAPElement requestdata= request.get_any();
            //extract the PO ID
            NodeList list = ((Element)requestdata).getElementsByTagName("poId");
            
            for (int loop = 0; loop < list.getLength(); loop++) {
                Node node = list.item(loop);
                if (node != null) {
                    Node child = node.getFirstChild();
                    if ((child != null) && child.getNodeValue() != null){
                        id = child.getNodeValue();
                    }
                }
            }

            SOAPElement replydata = xmlUtil.createSOAPMessage(id);
            reply = new SubmitPOResponse();
            reply.set_any(replydata);

        } catch(Exception exe){
            throw new RuntimeException("AnyPOService Having Problems:"+exe.getMessage(), exe);
        }

        //this is done just to illustrate throwing an application specific exception
        if(id.equals("100"))
            throw new InvalidPOException("Invalid ID for the purchase order!!! " +
                    "For demo purposes, we throw " +
                    "an application defined exception for the ID value of 100.");
        return reply;
    }
}

