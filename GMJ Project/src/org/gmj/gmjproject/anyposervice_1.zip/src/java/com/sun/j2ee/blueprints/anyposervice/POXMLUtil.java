/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: POXMLUtil.java,v 1.8 2005/12/01 20:53:16 yutayoshida Exp $ */

package com.sun.j2ee.blueprints.anyposervice;

import java.io.*;
import javax.xml.soap.*;
import javax.xml.transform.*;
import javax.xml.parsers.*;
import javax.xml.transform.dom.*;
import org.w3c.dom.*;

public class POXMLUtil {     
    
    public POXMLUtil() { 
    }
    
    /**
     * Method to create a SOAPElement
     * @param poID the ID for the purchase order created
     * @return SOAPElement
     * @throws Exception
     */
    
    public  SOAPElement createSOAPMessage(String poID) throws Exception {
        Document doc =createDocument(poID);
        if (doc == null)
            throw new IOException("Problem creating DOM ,createDocument() returned null ");
        SOAPElement parent = SOAPFactory.newInstance().createElement("dummy");
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.transform(new DOMSource(doc), new DOMResult(parent));
        return (SOAPElement) parent.getChildElements().next();
    }
    
    /**
     * Creates a DOM
     * @param poID the ID for the purchase order created
     * @return Document
     */
    
    private Document createDocument(String poID) throws Exception {
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
        docBuilderFactory.setValidating(false);
        docBuilderFactory.setNamespaceAware(true);
        DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
        Document doc = docBuilder.newDocument();
        Element  statusElem = doc.createElementNS("urn:AnyPurchaseOrderService","Status");
        doc.appendChild(statusElem);
        Element  elem = doc.createElement("poID");
        elem.appendChild(doc.createTextNode(poID));
        statusElem.appendChild(elem);
        return doc;
    }    
}

