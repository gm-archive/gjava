/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: LineItem.java,v 1.9 2005/08/12 19:43:02 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import org.w3c.dom.*;

public class LineItem {
    
    private String itemId;
    private int  quantity;
    private float  price;
    
    public LineItem() {}
    
    public LineItem(String itemId,
            int quantity, float price) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.price = price;
    }
    
    public String getItemId() {
        return this.itemId;
    }
    
    public int getQuantity() {
        return this.quantity;
    }
    
    public float getPrice() {
        return this.price;
    }
    
    public void setItemId(String itemId) {
        this.itemId = itemId;
        return;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
        return;
    }
    
    public void setPrice(float price) {
        this.price = price;
        return;
    }
    
    public Node toDOM(Document doc) {
        Element liElem = doc.createElement("items");
        Element elem = doc.createElement("itemId");
        elem.appendChild(doc.createTextNode(itemId));
        liElem.appendChild(elem);
        elem = doc.createElement("price");
        elem.appendChild(doc.createTextNode(String.valueOf(price)));
        liElem.appendChild(elem);
        elem = doc.createElement("quantity");
        elem.appendChild(doc.createTextNode(String.valueOf(quantity)));
        liElem.appendChild(elem);
        return liElem;
    }
}

