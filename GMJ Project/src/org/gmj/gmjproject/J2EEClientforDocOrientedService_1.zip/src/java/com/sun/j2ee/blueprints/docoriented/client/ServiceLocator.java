/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: ServiceLocator.java,v 1.3 2005/05/25 23:01:53 sean_brydon Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import javax.naming.*;
import java.rmi.Remote;
import javax.xml.rpc.*;

/**
 * Implements Service Locator pattern for Web services
 * It looks up resources for service references
 */
public class ServiceLocator {
    
    private transient InitialContext ic;

    public ServiceLocator() throws ServiceLocatorException  {
        try {
            setInitialContext();
        } catch (Exception e) {
            throw new ServiceLocatorException(e);
        }
    }

    private void setInitialContext() throws javax.naming.NamingException {
      ic = new InitialContext();
    }

    /**
     * Service class acts as a factory of the Dynamic proxy for the target service endpoint. 
     * @see java.xml.rpc.Service.java
     * @return the Service factory corresponding to jndi homeName
     */
    public Service getService(String jndiName) throws ServiceLocatorException {
        try {
            if (ic == null) setInitialContext();
            return (Service) ic.lookup(jndiName);
        } catch (Exception e) {
            throw new ServiceLocatorException("ServiceLocator can not lookup jndiName=" + jndiName,  e);
        }
    }

    /**
     * Service class acts as a factory of the Dynamic proxy for the target service endpoint. 
     * @see java.xml.rpc.Service.java
     * @return the Service instance
     */
    public Remote getServicePort(String jndiName, Class className) throws ServiceLocatorException {
        try {
            if (ic == null) setInitialContext();
            Service service = (Service) ic.lookup(jndiName);
            return service.getPort(className);
        } catch (Exception e) {
            throw new ServiceLocatorException("ServiceLocator can not lookup jndiName=" + jndiName + " and className=" + className,  e);
        }
    }
}
