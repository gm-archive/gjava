/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: JNDINames.java,v 1.1 2005/05/24 23:04:35 sean_brydon Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

/**
 * JNDI names of various Web Service References used by the client
 */
public class JNDINames {

    public static final String ANY_SERVICE_REF= "java:comp/env/service/AnyPurchaseOrderService";
    public static final String ANY_TYPE_SERVICE_REF= "java:comp/env/service/AnyTypePurchaseOrderService";   
    public static final String ATTACHMENT_SERVICE_REF= "java:comp/env/service/AttachmentPurchaseOrderService";   
    public static final String SCHEMA_SERVICE_REF= "java:comp/env/service/SchemaDefinedPurchaseOrderService";   
    public static final String STRING_SERVICE_REF= "java:comp/env/service/StringPurchaseOrderService";   
}
