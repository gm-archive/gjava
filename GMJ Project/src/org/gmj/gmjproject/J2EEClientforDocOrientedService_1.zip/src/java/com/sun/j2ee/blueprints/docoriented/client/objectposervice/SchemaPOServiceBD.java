/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: SchemaPOServiceBD.java,v 1.17 2005/06/02 03:20:04 sean_brydon Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.objectposervice;

import java.rmi.*;
import javax.naming.*;
import javax.xml.rpc.*;

import com.sun.j2ee.blueprints.docoriented.client.*;

/**
 * Implements the Business Delegate pattern for Web services.
 * Handles making the exchange of messages with the Web service endpoint
 */
public class SchemaPOServiceBD {
    
    private ServiceLocator serviceLocator;
     
    public SchemaPOServiceBD(){    
        serviceLocator = new ServiceLocator();  
    }
    
    /**
     * Accepts the PurchaseOrder built from client GUI inputs, and then
     * creates a PurchaseOrder.java object that is generated from the
     * service endpoint WSDL file.
     */
    public String submitPO(com.sun.j2ee.blueprints.docoriented.client.PurchaseOrder po) throws RequestHandlerException {
        
        try {       
            SchemaDefinedPurchaseOrderServiceSEI port = (SchemaDefinedPurchaseOrderServiceSEI)          
            serviceLocator.getServicePort(JNDINames.SCHEMA_SERVICE_REF, SchemaDefinedPurchaseOrderServiceSEI.class);
                      
            //create a Purchase Order object that is to be sent to the endpoint       
            Address shipTo = new Address();       
            shipTo.setStreet(po.getShipTo().getStreet());  
            shipTo.setCity(po.getShipTo().getCity());          
            shipTo.setState(po.getShipTo().getState());          
            shipTo.setPostalCode(po.getShipTo().getPostalCode());                   
            
            Address billTo = new Address();      
            billTo.setStreet(po.getBillTo().getStreet());          
            billTo.setCity(po.getBillTo().getCity());           
            billTo.setState(po.getBillTo().getState());         
            billTo.setPostalCode(po.getBillTo().getPostalCode());           
            
            com.sun.j2ee.blueprints.docoriented.client.LineItem[] items = po.getItems();          
            LineItem item1 = new LineItem();         
            item1.setItemId(items[0].getItemId());        
            item1.setQuantity(items[0].getQuantity());       
            item1.setPrice(items[0].getPrice());
            
            LineItem item2 = new LineItem();          
            item2.setItemId(items[1].getItemId());        
            item2.setQuantity(items[1].getQuantity());        
            item2.setPrice(items[1].getPrice());        
                    
            LineItem[] lineItems = new LineItem[2];        
            lineItems[0] = item1 ;        
            lineItems[1] = item2 ;     
            
            PurchaseOrder order = new PurchaseOrder();       
            order.setPoId(po.getPoId());     
            order.setCreateDate(po.getCreateDate());          
            order.setShipTo(shipTo);          
            order.setBillTo(billTo);        
            order.setItems(lineItems);
            
            String ret = port.submitPO(order);          
            return ret;
            
        } catch(InvalidPOException ipoe){           
            ipoe.printStackTrace(System.err);      
            throw new RequestHandlerException("Request Handler Exception: Service Endpoint Application-Defined Exception "+ipoe.getMessage(), ipoe);         
        } catch(RemoteException re){    
            re.printStackTrace(System.err);     
            throw new RuntimeException("The web service you are trying to access is not available. A possible reason could be that the service has not been deployed yet. "+ re.getMessage(), re);
        }         
    }
}

