/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AttachmentPOServiceBD.java,v 1.12 2005/08/12 19:43:04 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.attachmentposervice;

import java.rmi.*;
import java.io.*;
import java.net.*;

import javax.xml.transform.*;
import javax.xml.transform.stream.*;

import com.sun.j2ee.blueprints.docoriented.client.*;

/**
 * Implements the Business Delegate pattern for Web services.
 * Handles making the exchange of messages with the Web service endpoint
 */
public class  AttachmentPOServiceBD {
    
    private ServiceLocator serviceLocator;
    
    public  AttachmentPOServiceBD(){
        serviceLocator = new ServiceLocator();
    }
    
    public String submitPO(PurchaseOrder po) throws RequestHandlerException {
        try {
            AttachmentPurchaseOrderServiceSEI port = (AttachmentPurchaseOrderServiceSEI)
            serviceLocator.getServicePort(JNDINames.ATTACHMENT_SERVICE_REF,
                    AttachmentPurchaseOrderServiceSEI.class);
            String xmlDoc = po.toXMLString();
            Source src = new StreamSource(new StringReader(xmlDoc));
            URI resp= port.submitPO(src);
            return resp.getSchemeSpecificPart();
        } catch(InvalidPOException ipe){
            ipe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: Service Endpoint Application-Defined Exception "+ipe.getMessage(), ipe);
        } catch(RemoteException re){
            re.printStackTrace(System.err);
            throw new RuntimeException("The web service you are trying to access is not available. A possible reason could be that the service has not been deployed yet. "+ re.getMessage(), re);
        }
    }
}

