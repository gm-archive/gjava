/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: POEntityResolver.java,v 1.2 2005/08/10 20:28:03 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.stringposervice;

import org.xml.sax.*;
import java.io.*;

public class POEntityResolver implements EntityResolver {
    
    private static String RESOURCE_LOCATION = "/resources/";
    private static String BLUEPRINTS_NS = "http://java.sun.com/blueprints/schemas/";
    
    public InputSource resolveEntity(String publicId, String systemId) {
        if (systemId.equals(BLUEPRINTS_NS + "PurchaseOrder.xsd")) {
            return getClassPathSource("PurchaseOrder.xsd");
        } else{
            return null;
        }
    }
    
    private InputSource getClassPathSource(String name) {
        InputStream is =  null;
        try {
            is  = getClass().getResourceAsStream(RESOURCE_LOCATION + name);
            return new InputSource(is);
        } catch (Exception exe) {
            System.err.println("POEntityResolver error resolving: " + name);
            exe.printStackTrace();
        }
        return null;
    }
}

