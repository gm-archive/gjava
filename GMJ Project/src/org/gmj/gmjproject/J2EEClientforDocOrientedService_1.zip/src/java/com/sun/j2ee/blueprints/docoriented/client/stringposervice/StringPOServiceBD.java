/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: StringPOServiceBD.java,v 1.14 2005/08/12 20:45:30 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.stringposervice;

import java.rmi.*;
import java.io.*;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.*;

import com.sun.j2ee.blueprints.docoriented.client.*;

/**
 * Implements the Business Delegate pattern for Web services.
 * Handles making the exchange of messages with the Web service endpoint
 */

public class StringPOServiceBD {
    
    private ServiceLocator serviceLocator;
    
    public StringPOServiceBD(){
        serviceLocator = new ServiceLocator();
    }
    
    public String submitPO(PurchaseOrder po) throws RequestHandlerException {
        String ret = null;
        try {
            StringPurchaseOrderServiceSEI port = (StringPurchaseOrderServiceSEI)
            serviceLocator.getServicePort(JNDINames.STRING_SERVICE_REF, StringPurchaseOrderServiceSEI.class);
            String xmlDoc = po.toXMLString();
            if(!(validate(xmlDoc))){
                throw new RequestHandlerException("Request Handler Exception: Error parsing the purchase order XML document");
            }
            ret = port.submitPO(xmlDoc);
            return ret;
        } catch(InvalidPOException ipoe){
            ipoe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: Service Endpoint Application-Defined Exception "+ipoe.getMessage(), ipoe);
        } catch(RemoteException re){
            re.printStackTrace(System.err);
            throw new RuntimeException("The web service you are trying to access is not available. A possible reason could be that the service has not been deployed yet. "+ re.getMessage(), re);
        }
    }
    
    /**
     * Method to validate the XML doc
     * @param xmlDoc the doc to be validated
     * @return validation status
     */
    private boolean validate(String xmlDoc) {
        Document doc = null;
        try {
            DocumentBuilderFactory dbf = null;
            DocumentBuilder db = null;
            try {
                dbf = DocumentBuilderFactory.newInstance();
                dbf.setValidating(true);
                dbf.setNamespaceAware(true);
                dbf.setAttribute("http://java.sun.com/xml/jaxp/properties/schemaLanguage",
                        "http://www.w3.org/2001/XMLSchema");
                if (dbf != null){
                    db = dbf.newDocumentBuilder();
                }
                db.setEntityResolver(new POEntityResolver());
                db.setErrorHandler(new POXMLErrorHandler());
            } catch (ParserConfigurationException pce) {
                pce.printStackTrace(System.err);
                throw new RuntimeException(pce.getMessage(), pce);
            }
            InputSource is =  new InputSource(new StringReader(xmlDoc));
            doc = db.parse(is);
            return true;
        } catch (Exception e) {
            System.err.println("XML Validation Error " + e);
        }
        return false;
    }
}