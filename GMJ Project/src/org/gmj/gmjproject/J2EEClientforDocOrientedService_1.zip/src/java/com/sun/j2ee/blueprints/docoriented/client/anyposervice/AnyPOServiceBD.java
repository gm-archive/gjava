/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AnyPOServiceBD.java,v 1.15 2005/08/16 06:35:54 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.anyposervice;

import java.rmi.*;

import javax.xml.soap.*;

import org.w3c.dom.*;
import org.w3c.dom.Node;

import com.sun.j2ee.blueprints.docoriented.client.*;

/**
 * Implements the Business Delegate pattern for Web services.
 * Handles making the exchange of messages with the Web service endpoint
 */
public class AnyPOServiceBD {
    
    private ServiceLocator serviceLocator;
    
    
    public AnyPOServiceBD(){
        serviceLocator = new ServiceLocator();
    }
    
    public String submitPO(PurchaseOrder po) throws RequestHandlerException {
        try {
            //this flag is set not to generate a wrapper element 
            //like when using xsd:anyType
            boolean wrapper = false;
            AnyPurchaseOrderServiceSEI port = (AnyPurchaseOrderServiceSEI)
            serviceLocator.getServicePort(JNDINames.ANY_SERVICE_REF, AnyPurchaseOrderServiceSEI.class);
            SOAPElement requestSOAPElem = po.toXMLSOAPElement(wrapper);
            SubmitPO req = new SubmitPO();
            req.set_any(requestSOAPElem);
            SubmitPOResponse response = port.submitPO(req);
            SOAPElement responseSOAPElem = response.get_any();
            NodeList list = ((Element)responseSOAPElem).getElementsByTagNameNS("urn:AnyPurchaseOrderService","poID");
            String ret = null;
            for (int loop = 0; loop < list.getLength(); loop++) {
                Node node = list.item(loop);
                if (node != null) {
                    Node child = node.getFirstChild();
                    if ((child != null) && child.getNodeValue() != null){
                        ret = child.getNodeValue();
                    }
                }
            }
            return ret;
        } catch(InvalidPOException ipoe){
            ipoe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: Service Endpoint Application-Defined Exception "+ipoe.getMessage(), ipoe);
        } catch(RemoteException re){
            re.printStackTrace(System.err);
            throw new RuntimeException("The web service you are trying to access is not available. A possible reason could be that the service has not been deployed yet. "+ re.getMessage(), re);
        }
    }
}

