/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: FrontController.java,v 1.15 2005/05/31 23:29:56 sean_brydon Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Centralized controller for all the
 * incoming requests
 */
public class FrontController  extends HttpServlet {
    
    private Map nameSpace;
    private RequestHandler handler;

    public void init() {
        initPathMapping();
        handler = new RequestHandler();
    }

    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws
        IOException, ServletException {
        doGet(req, resp);
    }

    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws
        IOException, ServletException{
        process(req, resp);
    }

    protected void process(HttpServletRequest req, HttpServletResponse resp) throws 
                           IOException, ServletException                     {
        resp.setContentType("text/html");
        String responseURL = null;
        String fullURL = req.getRequestURI();

        // get the screen name
        String selectedURL = null;
        int lastPathSeparator = fullURL.lastIndexOf("/") + 1;
        if (lastPathSeparator != -1) {            
            selectedURL = fullURL.substring(lastPathSeparator, fullURL.length());
        }
        responseURL = getResponseURL(selectedURL);
        
        if (selectedURL.equals("invokeservice.do")) {
            try {
                handler.handle(req,resp);
            } catch (RequestHandlerException re) {
                req.setAttribute("error_message", re.getMessage());
                responseURL = getResponseURL("error.do");
            }
        } 
        getServletConfig().getServletContext()
                .getRequestDispatcher(responseURL).forward(req, resp);
    }

    protected String getResponseURL(String url) {
        return (String) nameSpace.get(url);
    }
                                                          
    protected void initPathMapping() {
        nameSpace = new HashMap();
        nameSpace.put("invokeservice.do", "/result.jsp");
        nameSpace.put("index.do", "/index.jsp");
        nameSpace.put("error.do", "/error.jsp");
    }
}
