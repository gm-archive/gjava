/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: PurchaseOrder.java,v 1.15 2005/08/16 06:35:54 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import java.util.*;
import java.io.*;
import java.text.*;

import javax.xml.parsers.*;
import javax.xml.soap.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

import org.w3c.dom.*;

/**
 * This object is represents the purchase order
 * that is persisted after a user places an order.
 */
public class PurchaseOrder {
    
    private String poId;
    private Calendar createDate;
    private Address shipTo;
    private Address billTo;
    private LineItem[] items;
    
    public PurchaseOrder() {}
    
    public PurchaseOrder(String poId, Calendar createDate,
            Address shipTo, Address billTo, LineItem[] items) {
        
        this.poId = poId;
        this.shipTo = shipTo;
        this.createDate = createDate;
        this.billTo = billTo;
        this.items = items;
    }
    
    // getter methods
    public String getPoId() {
        return poId;
    }
    
    public Calendar getCreateDate() {
        return createDate;
    }
    
    public Address getShipTo() {
        return shipTo;
    }
    
    public Address getBillTo() {
        return billTo;
    }
    
    public LineItem[] getItems() {
        return items;
    }
    
    // setter methods
    public void setPoId(String poId) {
        this.poId = poId;
    }
    
    public void setCreateDate(Calendar createDate) {
        this.createDate = createDate;
    }
    
    public void setShipTo(Address shipTo) {
        this.shipTo = shipTo;
    }
    
    public void setBillTo(Address billTo) {
        this.billTo = billTo;
    }
    
    public void setItems(LineItem[] item) {
        this.items =  item;
    }
    
    //XML serialization methods
    
    public String toXMLString() {
        String po = null;
        try {
            //construct the DOM tree
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setNamespaceAware(true);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();
            Element  poElem = doc.createElement("PurchaseOrder");
            poElem.setAttribute("xmlns:xsi",
                    "http://www.w3.org/2001/XMLSchema-instance");
            poElem.setAttribute("xsi:schemaLocation",
                    "http://java.sun.com/blueprints/ns/po " +
                    "http://java.sun.com/blueprints/schemas/PurchaseOrder.xsd");
            poElem.setAttribute("xmlns", "http://java.sun.com/blueprints/ns/po");
            doc.appendChild(poElem);
            Element  elem = doc.createElement("poId");
            elem.appendChild(doc.createTextNode(poId));
            poElem.appendChild(elem);
            elem = doc.createElement("createDate");
            elem.appendChild(doc.createTextNode((new SimpleDateFormat("yyyy-MM-dd")).format(createDate.getTime())));
            poElem.appendChild(elem);
            elem = doc.createElement("shipTo");
            poElem.appendChild(shipTo.toDOM(doc, elem));
            elem = doc.createElement("billTo");
            poElem.appendChild(billTo.toDOM(doc, elem));
            for(int i = 0; i < items.length; ++i){
                poElem.appendChild(items[i].toDOM(doc));
            }
            
            //process the source tree
            ByteArrayOutputStream baStream = new ByteArrayOutputStream();
            Result res = new StreamResult(baStream);
            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.METHOD, "xml");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(new DOMSource(doc), res);
            po = baStream.toString("UTF-8");
            
        } catch(ParserConfigurationException pce) {
            pce.printStackTrace(System.err);
            throw new RuntimeException(pce.getMessage(), pce);
        } catch(UnsupportedEncodingException use) {
            use.printStackTrace(System.err);
            throw new RuntimeException(use.getMessage(), use);
        } catch(TransformerException te) {
            te.printStackTrace(System.err);
            throw new RuntimeException(te.getMessage(), te);
        }
        
        return po;
    }
    
    
    public SOAPElement toXMLSOAPElement(boolean wrapper) {
        SOAPElement soapElem = null;
        try {
            //construct the DOM tree
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setNamespaceAware(true);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();
            Element  poElem = doc.createElement("PurchaseOrder");
            if(wrapper){
                Element  docElem = doc.createElement("BusinessDocumentRequest");
                doc.appendChild(docElem);
                docElem.appendChild(poElem);
            } else{
                doc.appendChild(poElem);
            }
            Element  elem = doc.createElement("poId");
            elem.appendChild(doc.createTextNode(poId));
            poElem.appendChild(elem);
            elem = doc.createElement("createDate");
            elem.appendChild(doc.createTextNode((new SimpleDateFormat("MM-dd-yy")).format(createDate.getTime())));
            poElem.appendChild(elem);
            elem = doc.createElement("shipTo");
            poElem.appendChild(shipTo.toDOM(doc, elem));
            elem = doc.createElement("billTo");
            poElem.appendChild(billTo.toDOM(doc, elem));
            for(int i = 0; i < items.length; ++i){
                poElem.appendChild(items[i].toDOM(doc));
            }
            
            //create a SOAPElement
            SOAPElement parent = SOAPFactory.newInstance().createElement("dummy");
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(new DOMSource(doc), new DOMResult(parent));
            soapElem = (SOAPElement) parent.getChildElements().next();
        } catch(TransformerException te) {
            te.printStackTrace(System.err);
            throw new RuntimeException(te.getMessage(), te);
        } catch(ParserConfigurationException pce) {
            pce.printStackTrace(System.err);
            throw new RuntimeException(pce.getMessage(), pce);
        } catch(SOAPException se) {
            se.printStackTrace(System.err);
            throw new RuntimeException(se.getMessage(), se);
        }
        return soapElem;
    }
}

