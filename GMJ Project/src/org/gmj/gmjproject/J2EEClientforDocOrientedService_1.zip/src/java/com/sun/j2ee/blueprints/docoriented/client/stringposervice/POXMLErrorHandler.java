/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: POXMLErrorHandler.java,v 1.1 2005/07/28 22:32:16 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.stringposervice;

import org.xml.sax.*;

public class POXMLErrorHandler implements ErrorHandler {
    
    public void warning(SAXParseException ex) throws SAXException {
        return;
    }
    
    public void error(SAXParseException ex) throws SAXException {
        throw ex;
    }
    
    public void fatalError(SAXParseException ex) throws SAXException {
        throw ex;
    }
}
