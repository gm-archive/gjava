/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: Address.java,v 1.9 2005/08/12 19:43:02 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import org.w3c.dom.*;

public class Address {

  private String street;
  private String city;
  private String state;
  private String postalCode;

  public Address() {}

  public Address(String street, String city,
                 String state, String postalCode) {
    this.street = street;
    this.city = city;
    this.state = state;
    this.postalCode = postalCode;
    return;
  }

  // getter methods
  public String getStreet() {
    return street;
  }

  public String getCity() {
    return city;
  }

  public String getState() {
    return state;
  }

  public String getPostalCode() {
    return postalCode;
  }

  // setter methods
  public void setStreet(String street) {
    this.street = street;
    return;
  }

  public void setCity(String city) {
    this.city = city;
    return;
  }

  public void setState(String state) {
    this.state = state;
    return;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
    return;
  }  

  public Node toDOM(Document doc, Element addrElem) {
    Element  elem = doc.createElement("street");      
    elem.appendChild(doc.createTextNode(street));
    addrElem.appendChild(elem); 
    elem = doc.createElement("city");     
    elem.appendChild(doc.createTextNode(city));
    addrElem.appendChild(elem); 
    elem = doc.createElement("state");          
    elem.appendChild(doc.createTextNode(state));
    addrElem.appendChild(elem); 
    elem = doc.createElement("postalCode");          
    elem.appendChild(doc.createTextNode(postalCode));
    addrElem.appendChild(elem);     
    return addrElem;
  }
}





