/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: RequestHandler.java,v 1.17 2005/08/12 19:43:03 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

import java.util.*;
import java.text.*;

import javax.servlet.http.*;

import com.sun.j2ee.blueprints.docoriented.client.stringposervice.*;
import com.sun.j2ee.blueprints.docoriented.client.objectposervice.*;
import com.sun.j2ee.blueprints.docoriented.client.anytypeposervice.*;
import com.sun.j2ee.blueprints.docoriented.client.anyposervice.*;
import com.sun.j2ee.blueprints.docoriented.client.attachmentposervice.*;

/**
 * Handles responsibilities related to getting HTTP request
 * info and making the calls to the Web service endpoint
 */
public class RequestHandler {
    private SchemaPOServiceBD schemaPOService;
    private StringPOServiceBD stringPOService;
    private AnyTypePOServiceBD anyTypePOService;
    private AnyPOServiceBD anyPOService;
    private AttachmentPOServiceBD attachmentPOService;
    
    public RequestHandler(){
        schemaPOService = new SchemaPOServiceBD();
        stringPOService = new StringPOServiceBD();
        anyTypePOService = new AnyTypePOServiceBD();
        anyPOService = new AnyPOServiceBD();
        attachmentPOService = new AttachmentPOServiceBD();
    }
    
    /**
     * Handles the http request, calls the appropriate Business Delegate
     * to access the web service, and provides an appropriate response.
     * Sets the response message by setting a request attribute for use
     * in the client JSP pages.
     * @throws RequestHandlerException with client message for
     * bad date format, bad number format, servicelocator JNDI lookup
     * problems, web service application defined exceptions,
     * web service access problems so that user can know about
     * a possible corrective action. Also, throws RequestHandlerException
     * thrown from calling delegate to access service when got a
     * service-defined application exception.
     */
    public void handle(HttpServletRequest request,
            HttpServletResponse response) throws RequestHandlerException{
        try {
            String ret = null;
            //extract request parameters
            String poID = request.getParameter("po_id");
            if((poID == null) || (poID.equals("")))
                throw new RequestHandlerException("Request Handler Exception: Please enter a valid PO ID.");
            String orderDate = request.getParameter("po_date");
            String itemId1 = request.getParameter("po_itemID1");
            String quantity1 = request.getParameter("po_quantity1");
            String unitPrice1 = request.getParameter("po_unitPrice1");
            String itemId2 = request.getParameter("po_itemID2");
            String quantity2 = request.getParameter("po_quantity2");
            String unitPrice2 = request.getParameter("po_unitPrice2");
            Address shipTo = new Address(request.getParameter("po_shipping_street"),
                    request.getParameter("po_shipping_city"),
                    request.getParameter("po_shipping_state"),
                    request.getParameter("po_shipping_zipCode"));
            Address billTo = new Address(request.getParameter("po_billing_street"),
                    request.getParameter("po_billing_city"),
                    request.getParameter("po_billing_state"),
                    request.getParameter("po_billing_zipCode"));
            LineItem item1 = new LineItem(itemId1,
                    Integer.parseInt(quantity1), Float.valueOf(unitPrice1).floatValue());
            LineItem item2 = new LineItem(itemId2,
                    Integer.parseInt(quantity2), Float.valueOf(unitPrice2).floatValue());
            LineItem[] items = new LineItem[2];
            items[0] = item1 ;
            items[1] = item2 ;
            Date date = new SimpleDateFormat("yyyy-MM-dd").parse(orderDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            //create a Purchase Order object
            PurchaseOrder po = new PurchaseOrder();
            po.setPoId(poID);
            po.setCreateDate(cal);
            po.setShipTo(shipTo);
            po.setBillTo(billTo);
            po.setItems(items);
            if(request.getParameter("type").equals("String")){
                ret = stringPOService.submitPO(po);
            } else if(request.getParameter("type").equals("Object")){
                ret = schemaPOService.submitPO(po);
            } else if(request.getParameter("type").equals("AnyType")){
                ret = anyTypePOService.submitPO(po);
            } else if(request.getParameter("type").equals("Any")){
                ret = anyPOService.submitPO(po);
            } else if(request.getParameter("type").equals("Attachment")){
                ret = attachmentPOService.submitPO(po);
            }
            request.setAttribute("result", ret);
        } catch(java.text.ParseException pe){
            //catch exception for date format, when creating XML doc of
            //purchase order before sending xml document to webservice
            pe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: Date format in PurchaseOrder input form needs to be like 2005-08-12. You entered an unexpected value for the date "+ pe.getMessage());
        } catch(java.lang.NumberFormatException nfe){
            //catch exception for number format, when creating XML doc of
            //purchase order before sending xml document to webservice
            nfe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: For PurchaseOrder user input form, you need to use proper number format. You entered an unexpected value "+ nfe.getMessage());
        }
    }
}