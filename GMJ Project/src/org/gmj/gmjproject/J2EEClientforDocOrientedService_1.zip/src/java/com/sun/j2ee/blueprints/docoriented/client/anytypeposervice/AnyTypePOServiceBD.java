
/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AnyTypePOServiceBD.java,v 1.14 2005/08/16 06:35:55 smitha Exp $ */

package com.sun.j2ee.blueprints.docoriented.client.anytypeposervice;

import java.rmi.*;

import javax.xml.soap.*;

import com.sun.j2ee.blueprints.docoriented.client.*;

/**
 * Implements the Business Delegate pattern for Web services.
 *  Handles making the exchange of messages with the Web service endpoint
 */
public class AnyTypePOServiceBD {
    
    private ServiceLocator serviceLocator;
    
    public AnyTypePOServiceBD(){
        serviceLocator = new ServiceLocator();
    }
    
    public String submitPO(PurchaseOrder po) throws RequestHandlerException {
        try {
            //this flag is to generate a wrapper element BusinessDocumentRequest
            //as defined in the WSDL
            boolean wrapper = true;
            AnyTypePurchaseOrderServiceSEI port = (AnyTypePurchaseOrderServiceSEI)
            serviceLocator.getServicePort(JNDINames.ANY_TYPE_SERVICE_REF,
                    AnyTypePurchaseOrderServiceSEI.class);
            SOAPElement requestSOAPElem = po.toXMLSOAPElement(wrapper);                   
            return port.submitPO(requestSOAPElem);
        } catch(InvalidPOException ipe){
            ipe.printStackTrace(System.err);
            throw new RequestHandlerException("Request Handler Exception: Service Endpoint Application-Defined Exception "+ipe.getMessage(), ipe);
        } catch(RemoteException re){
            re.printStackTrace(System.err);
            throw new RuntimeException("The web service you are trying to access is not available. A possible reason could be that the service has not been deployed yet. "+ re.getMessage(), re);
        }
    }
}

