/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: RequestHandlerException.java,v 1.7 2005/05/31 23:29:56 sean_brydon Exp $ */

package com.sun.j2ee.blueprints.docoriented.client;

/**
 * An application exception indicating something has gone wrong
 * These are errors which the application could potentially 
 * take some corrective action on, such as asking a user to 
 * provide a date in a certain format or make sure all fields 
 * in a form have values
 *
 */
public class RequestHandlerException extends Exception {

    public RequestHandlerException() {}
    public RequestHandlerException(String msg) { super(msg); }
    public RequestHandlerException(String msg, Throwable cause) { super(msg, cause); }
    public RequestHandlerException(Throwable cause) { super(cause); }
}
