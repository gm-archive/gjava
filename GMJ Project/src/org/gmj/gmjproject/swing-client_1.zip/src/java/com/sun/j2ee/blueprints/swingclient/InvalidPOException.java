/* Copyright 2004 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: InvalidPOException.java,v 1.1 2005/05/27 00:07:38 inder Exp $ */

package com.sun.j2ee.blueprints.swingclient;

public class InvalidPOException extends Exception {
    private String message;
    
    public InvalidPOException(String message) {
        super(message);
        this.message = message;
    }
    
    public InvalidPOException(Throwable cause) {
        super(cause);
    }
    
    public InvalidPOException(String message, Throwable cause) {
        super(message, cause);
        this.message = message;
    }
    
    public String getMessage() {
        return message;
    }
}
