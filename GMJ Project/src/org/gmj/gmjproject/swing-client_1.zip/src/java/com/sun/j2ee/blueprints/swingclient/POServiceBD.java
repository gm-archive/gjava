/* Copyright 2004 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: POServiceBD.java,v 1.5 2005/05/27 23:45:28 inder Exp $ */

package com.sun.j2ee.blueprints.swingclient;
import java.rmi.RemoteException;
import java.net.URL;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.Call;
import javax.xml.rpc.Stub;
import javax.xml.rpc.ServiceFactory;
import javax.xml.rpc.Service;
import javax.xml.rpc.ParameterMode;
import javax.xml.namespace.QName;

/**
 * This delegate class illustrates how a web service call can be made using Stubs, Dynamic Proxy, or DII.
 * It isolates the client from Web service artifacts such as the classes generated from WSDL. To achieve that 
 * it converts the service exceptions to local exception types. 
 * @author Inderjeet Singh
 */
public class POServiceBD {
    
    /** The namespace used by the body of the WSDL file. This constant is needed for dynamic proxy and DII. */
    private static final String NS_BODY = "urn:StringPurchaseOrderService";
    
    public POServiceBD(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }
    
    /** This method shows how the submitPO web service method can be invoked using stubs */
    public String submitPOUsingStubs(String xmlDocStr) throws InvalidPOException {
        try {
            com.sun.j2ee.blueprints.stringposervice.StringPurchaseOrderService_Impl svcimpl = new com.sun.j2ee.blueprints.stringposervice.StringPurchaseOrderService_Impl();
            com.sun.j2ee.blueprints.stringposervice.StringPurchaseOrderServiceSEI poservice = svcimpl.getStringPurchaseOrderServiceSEIPort();
            ((Stub)poservice)._setProperty(Stub.ENDPOINT_ADDRESS_PROPERTY, serviceUrl);
            return poservice.submitPO(xmlDocStr);
        } catch (com.sun.j2ee.blueprints.stringposervice.InvalidPOException e) {
            throw new InvalidPOException(e);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
    }
    
    /** This method shows how the submitPO web service method can be invoked using a dynamic proxy */
    public String submitPOUsingDynamicProxy(String xmlDocStr) throws InvalidPOException {
        try {
            ServiceFactory sf = ServiceFactory.newInstance();
            URL wsdlURL = new URL(serviceUrl + "?WSDL");
            QName serviceQname = new QName(NS_BODY, "StringPurchaseOrderService");
            Service s = sf.createService(wsdlURL, serviceQname);
            QName portQname = new QName(NS_BODY, "StringPurchaseOrderServiceSEIPort");
            com.sun.j2ee.blueprints.stringposervice_wrapped.StringPurchaseOrderServiceSEI port = (com.sun.j2ee.blueprints.stringposervice_wrapped.StringPurchaseOrderServiceSEI)
            s.getPort(portQname, com.sun.j2ee.blueprints.stringposervice_wrapped.StringPurchaseOrderServiceSEI.class);
            com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPO param = new com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPO(xmlDocStr);
            com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPOResponse response = port.submitPO(param);
            return response.getResult();
        } catch (com.sun.j2ee.blueprints.stringposervice_wrapped.InvalidPOException e) {
            throw new InvalidPOException(e);
        } catch (ServiceException se) {
            throw new InvalidPOException(se);
        } catch (java.net.MalformedURLException mfue) {
            throw new RuntimeException(mfue);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
    }
    
    /** This method shows how the submitPO web service method can be invoked using DII */
    public String submitPOUsingDII(String xmlDocStr) throws InvalidPOException {
        try {
            ServiceFactory sf = ServiceFactory.newInstance();
            URL wsdlURL = new URL(serviceUrl + "?WSDL");
            QName serviceQname = new QName(NS_BODY, "StringPurchaseOrderService");
            Service s = sf.createService(wsdlURL, serviceQname);
            QName portQname = new QName(NS_BODY, "StringPurchaseOrderServiceSEIPort");
            
            Call call = s.createCall(portQname);
            call.setTargetEndpointAddress(serviceUrl);
            call.setProperty(Call.SOAPACTION_USE_PROPERTY, new Boolean(true));
            call.setProperty(Call.SOAPACTION_URI_PROPERTY,"");
            
            // For WS-I compliant document-literal, need to set the encoding style
            // to literal by specifying "" as the encoding style,
            // and by setting the operation style to document
            String ENCODING_STYLE_PROPERTY = "javax.xml.rpc.encodingstyle.namespace.uri";
            String URI_ENCODING = "";
            call.setProperty(ENCODING_STYLE_PROPERTY, URI_ENCODING);
            call.setProperty(Call.OPERATION_STYLE_PROPERTY, "document");
            
            // Note that the operation name need not be set by calling
            // call.setOperationName(new QName(NS_BODY, "submitPO"));
            // This is because the SOAP binding used by the Web service is document, not rpc.
            
            // The types for the request parameter and return value are defined in the
            // WSDL file itself, so their qnames are defined with the namespace of the body
            QName requestQname = new QName(NS_BODY, "submitPO");
            QName responseQname = new QName(NS_BODY, "submitPOResponse");
            
            // Define the type of the return value for the DII call.
            // SubmitPOResponse must match the wrapped type sent by the Web service.
            call.setReturnType(responseQname, com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPOResponse.class);
            
            // Define the type of the method parameter for the DII call.
            // In the WSDL file, the name of the message part for submitPO is "parameters"
            // Hence the request parameter is defined in this way.
            call.addParameter("parameters", requestQname, com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPO.class, ParameterMode.IN);
            com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPO param = new com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPO(xmlDocStr);
            Object[] params = {param};
            
            // Invoke the DII call
            com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPOResponse response = (com.sun.j2ee.blueprints.stringposervice_wrapped.SubmitPOResponse) call.invoke(params);
            
            return response.getResult();
        } catch (ServiceException e) {
            throw new InvalidPOException(e);
        } catch (java.net.MalformedURLException mfue) {
            throw new RuntimeException(mfue);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
    }
    
    private String serviceUrl;
}
