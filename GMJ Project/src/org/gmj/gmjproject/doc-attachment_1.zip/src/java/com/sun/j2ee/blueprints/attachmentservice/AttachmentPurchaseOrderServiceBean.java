/* Copyright 2005 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AttachmentPurchaseOrderServiceBean.java,v 1.13 2005/08/12 20:46:25 smitha Exp $ */

package  com.sun.j2ee.blueprints.attachmentservice;

import java.net.*;
import java.rmi.*;
import java.util.*;

import javax.ejb.*;
import javax.xml.soap.*;
import javax.xml.transform.*;
import javax.xml.rpc.handler.*;
import javax.xml.transform.dom.*;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class AttachmentPurchaseOrderServiceBean implements SessionBean {
    
    private SessionContext sc;
    private TransformerFactory transfactory;
    
    public AttachmentPurchaseOrderServiceBean() {}
    
    /**
     * This method implements a web service that processes an XML purchase
     * order document it receives as an attachment
     * and returns a WS-I Attachment profile conformat message
     * using the swaRef data type
     */
    public java.net.URI submitPO(Source xmlsrc) throws InvalidPOException, RemoteException{
        URI uri = null;
        String id = null;
        try {
            Transformer transformer = transfactory.newTransformer();
            DOMResult result = new DOMResult();
            transformer.transform(xmlsrc, result);
            Document doc = (Document)result.getNode();
            Element root = doc.getDocumentElement();
            NodeList list = root.getElementsByTagName("poId");
            for (int loop = 0; loop < list.getLength(); loop++) {
                Node node = list.item(loop);
                if (node != null) {
                    Node child = node.getFirstChild();
                    if ((child != null) && child.getNodeValue() != null) id = child.getNodeValue();
                }
            }
            MessageContext mc = sc.getMessageContext();
            AttachmentPart att = MessageFactory.newInstance().createMessage().createAttachmentPart();
            att.setContentId(" < "+ id + " >");
            att.setContent("<submitPO response/>","text/plain");
            ArrayList arrList = new ArrayList();
            arrList.add(att);
            // app server implementation specific
            mc.setProperty("com.sun.xml.rpc.attachment.SetAttachmentContext", arrList);
            uri = new java.net.URI("cid:" + id);
        } catch (Exception e) {
            throw new EJBException("AttachmentPOService Having Problems:"+e.getMessage(),  e);
        }
        //this is done just to illustrate throwing an application specific exception
        if(id.equals("100"))
            throw new InvalidPOException("Invalid ID for the purchase order!!! " +
                    "For demo purposes, we throw " +
                    "an application defined exception for the ID value of 100.");
        return uri;
    }
    
    //life cycle methods
    public void ejbCreate() throws CreateException {
        transfactory = TransformerFactory.newInstance();
    }
    
    public void setSessionContext(SessionContext sc) {
        this.sc = sc;
    }
    
    public void ejbRemove() {
        transfactory=null;
    }
    
    public void ejbActivate() {}
    
    public void ejbPassivate() {}
}



