/* Copyright 2004 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at: 
 http://developer.sun.com/berkeley_license.html
 $Id: POXMLUtil.java,v 1.4 2005/08/12 20:46:12 smitha Exp $ */

package com.sun.j2ee.blueprints.anytypeposervice;

import java.io.*;
import java.util.Date;

import javax.xml.soap.*;
import javax.xml.transform.*;
import javax.xml.parsers.*;
import javax.xml.transform.dom.*;

import org.w3c.dom.*;
import org.xml.sax.*;

public class POXMLUtil {
    
    private DocumentBuilderFactory factory;
    
    /** Creates a new instance of POXMLUtil */    
    public POXMLUtil() {
        factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(false);
        factory.setNamespaceAware(true);
    }       
        
    /**
     * Method to create a SOAPElement
     * @param poID the ID for the purchase order created
     * @return SOAPElement
     * @throws Exception
     */
    
    public SOAPElement createSOAPMessage(String poID) throws Exception {
        Document doc = createDOMFromString(poID);
        if (doc == null)
            throw new IOException("Problem reading cand creating DOM from file,readFileCreateDocument() returned null ");

        SOAPElement parent = SOAPFactory.newInstance().createElement("dummy");
        TransformerFactory factory = TransformerFactory.newInstance();
        Transformer transformer = factory.newTransformer();
        transformer.transform(new DOMSource(doc), new DOMResult(parent));
        return (SOAPElement) parent.getChildElements().next();
    }

        
    /**
     * Creates a DOM from String
     * @param poID the ID for the purchase order created
     * @return Document
     */
    
    private Document createDOMFromString(String poID) throws Exception {
       
        // Use the factory to create a DOM parser
        DocumentBuilder parser = factory.newDocumentBuilder();
        InputSource in = new InputSource();
        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<tns:BusinessDocumentReply xmlns:tns=\"urn:AnyTypePurchaseOrderService\">\n" +
            "<tns:Status xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://com.sun.j2ee.blueprints.anytypeposervice/types PurchaseOrderStatus.xsd\">\n" +
            "    <orderid> "+ poID + " </orderid>\n" +
            "    <timestamp>"+ new Date().toString()+"</timestamp>\n" +
            "</tns:Status>\n" +
            "</tns:BusinessDocumentReply>";
        in.setCharacterStream(new StringReader(xml));
        Document dom = parser.parse(in);
        return dom;
    }    
}
