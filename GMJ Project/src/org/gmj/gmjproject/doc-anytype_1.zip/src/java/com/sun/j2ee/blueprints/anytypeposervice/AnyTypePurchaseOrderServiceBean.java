/* Copyright 2004 Sun Microsystems, Inc.  All rights reserved.  You may not modify, use, reproduce, or distribute this software except in compliance with the terms of the License at:
 http://developer.sun.com/berkeley_license.html
 $Id: AnyTypePurchaseOrderServiceBean.java,v 1.12 2005/08/12 20:46:12 smitha Exp $ */

package com.sun.j2ee.blueprints.anytypeposervice;

import java.rmi.*;

import javax.ejb.*;
import javax.xml.soap.*;

import org.w3c.dom.*;
import org.w3c.dom.Node;

public class AnyTypePurchaseOrderServiceBean implements SessionBean {
    
    private SessionContext sc;
    private POXMLUtil xmlUtil;
    
    public AnyTypePurchaseOrderServiceBean() {}
    
    public String submitPO(SOAPElement request) throws InvalidPOException, RemoteException {
        String poID = null;
        SOAPElement reply = null;
        try {
            NodeList list = ((Element)request).getElementsByTagName("poId");
            for (int loop = 0; loop < list.getLength(); loop++) {
                Node node = list.item(loop);
                if (node != null) {
                    Node child = node.getFirstChild();
                    if ((child != null) && child.getNodeValue() != null){
                        poID = child.getNodeValue();
                    }
                }
            }                       
        } catch (Exception exe) {
            throw new EJBException("AnyTypePOService Having Problems:"+exe.getMessage(), exe);
        }
        //this is done just to illustrate throwing an application specific exception
        if(poID.equals("100"))
            throw new InvalidPOException("Invalid ID for the purchase order!!! " +
                    "For demo purposes, we throw " +
                    "an application defined exception for the ID value of 100.");
        return poID;
    }
    
    //life cycle methods
    public void ejbCreate() throws CreateException {
        xmlUtil = new POXMLUtil();
    }
    
    public void setSessionContext(SessionContext sc) {
        this.sc = sc;
    }
    
    public void ejbRemove(){}
    
    public void ejbActivate() {}
    
    public void ejbPassivate() {}
}

